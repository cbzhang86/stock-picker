# _legacy — 归档区（勿删除，勿接入）

本目录存放**路径迁移遗留的空壳文件**，均为 0 字节，无任何代码引用。

## 归档清单（2026-09-03）

| 文件 | 原路径 | 大小 | 真实库位置 | 说明 |
|---|---|---|---|---|
| `backtest_cache.db` | `data/db/backtest_cache.db` | 0 B | `data/cache/backtest_cache.db` | 回测库已迁至 `data/cache/`，`backtest_store.py:33` 指向新位置 |
| `kline_cache.db` | `data/db/kline_cache.db` | 0 B | `data/cache/kline_cache.db`（30 MB） | K 线库已迁至 `data/cache/`，`data_engine.py:83` 指向新位置 |
| `predictions.db` | `data/predictions.db` | 0 B | `data/db/predictions.db`（196 KB） | 推荐库已迁至 `data/db/`，`feedback/tracker.py:24` 指向新位置 |

## 为什么保留而不删除

三个文件都是**旧路径的占位空壳**，由早期版本创建。删除无任何收益，保留可用于
追溯路径迁移历史。若未来发现某处代码仍指向旧路径，可从这里确认其为空壳而非数据丢失。

**注意**：三个文件均为 0 字节，**不含任何数据**。若需要恢复旧路径，直接删除即可让
代码重新创建，无需从本目录复制回去。
